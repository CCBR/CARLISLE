utils::globalVariables(c("theta", "x_raw", "y_raw",
                         "A", "B", "C", "D", "group",
                         "head", "hjust", "n", "text",
                         "vjust", "x", "y"))
